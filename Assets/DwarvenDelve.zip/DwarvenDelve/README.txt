Hey! Thanks for downloading the Dwarven Delve asset pack by lyime @itch.io

Free License:
This asset pack can be used in non-commercial projects only. 
You can modify it to suit your own needs. 
You may not redistribute it or resell it. 
Please credit me by linking to my profile (https://lyime.itch.io/).


If you enjoy this, please leave a rating and comment! It helps to support the project! :)
